const fs = require('fs');
let html = fs.readFileSync('index.html', 'utf8');

const oldCss = `:root{
  --bg:#0a0a0f;--bg2:#111118;--bg3:#1a1a24;--bg4:#22222e;
  --accent:#e8c97a;--accent2:#c17d3c;--text:#f0ede6;--text2:#a09d96;--text3:#5a5855;
  --red:#d64f3c;--green:#4caf7d;--blue:#5b9bd6;--purple:#9b7fd6;
  --font-display:'Playfair Display',serif;--font-body:'DM Sans',sans-serif;
  --r:10px;--r2:6px;
  --tmdb-green:#01b4e4;
}`;

const newCss = `:root{
  --bg:#000000;--bg2:#111118;--bg3:#1a1a24;--bg4:#22222e;
  --accent:#e8c97a;--accent2:#c17d3c;--text:#f0ede6;--text2:#a09d96;--text3:#5a5855;
  --red:#d64f3c;--green:#4caf7d;--blue:#5b9bd6;--purple:#9b7fd6;
  --font-display:'Playfair Display',serif;--font-body:'DM Sans',sans-serif;
  --r:10px;--r2:6px;
  --tmdb-green:#01b4e4;
}

/* =========================================
   ESTILOS DEL HERO BANNER
   ========================================= */
.hero-banner {
  position: relative;
  width: 100%;
  height: 55vh; /* Ocupa un poco más de la mitad de la pantalla */
  min-height: 400px;
  background-size: cover;
  background-position: center 20%;
  display: flex;
  align-items: flex-end;
  padding: 40px 32px;
  margin-bottom: 32px;
  border-bottom: 1px solid rgba(255,255,255,0.05);
}

.hero-overlay {
  position: absolute;
  inset: 0;
  /* Degradado doble: oscurece la parte inferior para fundirse con el fondo de la app, y oscurece la izquierda para que el texto sea legible */
  background: linear-gradient(to top, var(--bg) 0%, transparent 70%), 
              linear-gradient(to right, rgba(0,0,0,0.85) 0%, transparent 60%);
}

.hero-content {
  position: relative;
  z-index: 2;
  max-width: 650px;
  animation: fadeUp 0.8s ease-out forwards;
}

.hero-type {
  color: var(--accent);
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 2px;
  font-weight: 700;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  gap: 6px;
}

.hero-title {
  font-family: var(--font-display);
  font-size: 48px;
  font-weight: 700;
  line-height: 1.1;
  margin-bottom: 12px;
  color: #ffffff;
  text-shadow: 0 4px 12px rgba(0,0,0,0.5);
}

.hero-overview {
  font-size: 14px;
  color: var(--text2);
  line-height: 1.6;
  margin-bottom: 24px;
  display: -webkit-box;
  -webkit-line-clamp: 3; /* Corta el texto largo a 3 líneas con puntos suspensivos */
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-shadow: 0 2px 4px rgba(0,0,0,0.8);
}

.hero-actions {
  display: flex;
  gap: 12px;
}

.btn-hero {
  background: var(--text);
  color: var(--bg);
  border: none;
  padding: 12px 28px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  font-family: var(--font-body);
  display: flex;
  align-items: center;
  gap: 8px;
  transition: all 0.2s ease;
}

.btn-hero:hover {
  transform: scale(1.03);
  background: #ffffff;
}

.btn-hero-secondary {
  background: rgba(255,255,255,0.15);
  color: var(--text);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255,255,255,0.1);
}

.btn-hero-secondary:hover {
  background: rgba(255,255,255,0.25);
}

@keyframes fadeUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}

@media(max-width: 768px) {
  .hero-banner { height: 60vh; padding: 24px 20px; }
  .hero-title { font-size: 32px; }
  .hero-overlay { background: linear-gradient(to top, var(--bg) 0%, var(--bg) 15%, transparent 80%), linear-gradient(to right, rgba(0,0,0,0.8) 0%, transparent 100%); }
}`;

const oldHtml = `<div id="view-home" class="view active">
    <div class="stats-row">
      <div class="stat-card"><div class="stat-label">Vistas</div><div class="stat-val" id="s-seen">0</div></div>
      <div class="stat-card"><div class="stat-label">Watchlist</div><div class="stat-val" id="s-want">0</div></div>
      <div class="stat-card"><div class="stat-label">Viendo</div><div class="stat-val" id="s-watching">0</div></div>
      <div class="stat-card"><div class="stat-label">Tiempo Est.</div><div class="stat-val" id="s-hours">0</div></div>
    </div>
    <div class="section-header">
      <div class="section-title">Mi catálogo</div>
      <div class="filter-row">
        <button class="filter-btn active" onclick="setFilter('all',this)">Todo</button>
        <button class="filter-btn" onclick="setFilter('movie',this)">Películas</button>
        <button class="filter-btn" onclick="setFilter('tv',this)">Series</button>
        <button class="filter-btn" onclick="setFilter('seen',this)">Vistas</button>
      </div>
    </div>
    <div class="films-grid" id="films-grid"></div>
  </div>`;

const newHtml = `<div id="view-home" class="view active" style="padding-top: 0; padding-left: 0; padding-right: 0;">
    <div id="hero-container"></div>
    <div style="padding: 0 24px;">
      <div class="stats-row">
        <div class="stat-card"><div class="stat-label">Vistas</div><div class="stat-val" id="s-seen">0</div></div>
        <div class="stat-card"><div class="stat-label">Watchlist</div><div class="stat-val" id="s-want">0</div></div>
        <div class="stat-card"><div class="stat-label">Viendo</div><div class="stat-val" id="s-watching">0</div></div>
        <div class="stat-card"><div class="stat-label">Tiempo Est.</div><div class="stat-val" id="s-hours">0</div></div>
      </div>
      <div class="section-header">
        <div class="section-title">Mi catálogo</div>
        <div class="filter-row">
          <button class="filter-btn active" onclick="setFilter('all',this)">Todo</button>
          <button class="filter-btn" onclick="setFilter('movie',this)">Películas</button>
          <button class="filter-btn" onclick="setFilter('tv',this)">Series</button>
          <button class="filter-btn" onclick="setFilter('seen',this)">Vistas</button>
        </div>
      </div>
      <div class="films-grid" id="films-grid"></div>
    </div>
  </div>`;

const oldJs = `// CARGA INICIAL
renderGrid();`;

const newJs = `async function loadHeroBanner() {
  const container = document.getElementById('hero-container');
  let key = getCfg('tmdb_key', DEFAULT_TMDB);
  
  try {
    // Buscamos la película número 1 en tendencias globales ahora mismo
    const res = await fetch(\`https://api.themoviedb.org/3/trending/movie/day?api_key=\${key}&language=es-MX\`);
    const data = await res.json();
    
    if(data.results && data.results.length > 0) {
      const heroFilm = data.results[0];
      
      // Pedimos el backdrop en tamaño original/1280 para que no se vea pixelado
      const backdropUrl = \`https://image.tmdb.org/t/p/w1280\${heroFilm.backdrop_path}\`;
      
      container.innerHTML = \`
        <div class="hero-banner" style="background-image: url('\${backdropUrl}');">
          <div class="hero-overlay"></div>
          <div class="hero-content">
            <div class="hero-type"><i class="ti ti-flame"></i> Tendencia Global</div>
            <h1 class="hero-title">\${heroFilm.title}</h1>
            <p class="hero-overview">\${heroFilm.overview || 'Sin descripción disponible.'}</p>
            <div class="hero-actions">
              <button class="btn-hero" onclick="quickAddMapped(\${heroFilm.id}, '\${heroFilm.title.replace(/'/g, "")}', '\${heroFilm.release_date.split('-')[0]}', '\${heroFilm.poster_path}', '\${heroFilm.overview.replace(/'/g, "")}', 'movie', '')">
                <i class="ti ti-plus"></i> Añadir a mi lista
              </button>
              <button class="btn-hero btn-hero-secondary">
                <i class="ti ti-info-circle"></i> Detalles
              </button>
            </div>
          </div>
        </div>
      \`;
    }
  } catch (e) {
    console.error("Error cargando el Hero Banner", e);
    // Si falla el internet, no mostramos nada y la app sigue funcionando normal
    container.innerHTML = '';
  }
}

// Asegúrate de llamar a loadHeroBanner() en tu carga inicial, justo al lado de renderGrid():
loadHeroBanner();
renderGrid();`;

let failed = false;

if (html.includes(oldCss)) {
  html = html.replace(oldCss, newCss);
} else {
  console.log("Could not find oldCss");
  failed = true;
}

if (html.includes(oldHtml)) {
  html = html.replace(oldHtml, newHtml);
} else {
  console.log("Could not find oldHtml");
  failed = true;
}

if (html.includes(oldJs)) {
  html = html.replace(oldJs, newJs);
} else {
  console.log("Could not find oldJs");
  failed = true;
}

if (!failed) {
  fs.writeFileSync('index.html', html, 'utf8');
  console.log("Successfully patched index.html");
}
